-- Travel & Tourism Management System schema
CREATE DATABASE IF NOT EXISTS travel_db;
USE travel_db;

CREATE TABLE IF NOT EXISTS Account (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL,
  role VARCHAR(50) DEFAULT 'staff'
);

CREATE TABLE IF NOT EXISTS Customer (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  phone VARCHAR(50),
  email VARCHAR(150),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS PackageTbl (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  description TEXT,
  price DECIMAL(10,2),
  seats INT DEFAULT 0
);

CREATE TABLE IF NOT EXISTS Hotel (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  city VARCHAR(100),
  price_per_night DECIMAL(10,2)
);

CREATE TABLE IF NOT EXISTS Booking (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT,
  package_id INT,
  hotel_id INT,
  booking_date DATE,
  status VARCHAR(50),
  FOREIGN KEY (customer_id) REFERENCES Customer(id) ON DELETE SET NULL,
  FOREIGN KEY (package_id) REFERENCES PackageTbl(id) ON DELETE SET NULL,
  FOREIGN KEY (hotel_id) REFERENCES Hotel(id) ON DELETE SET NULL
);

-- sample admin user (password is 'admin' - change in production)
INSERT IGNORE INTO Account (username, password, role) VALUES ('admin','admin','admin');
