# Travel & Tourism Management System (Java Swing + MySQL + Ant)

## What is included
- Java Swing GUI (src/com/travel/app)
- Ant build file (`build.xml`)
- SQL schema to create database and tables (`sql/schema.sql`)
- `lib/` folder for JDBC driver (place MySQL connector jar here)
- README with instructions

## Requirements
- Java JDK (11+ recommended)
- Apache Ant
- MySQL server
- MySQL JDBC driver (mysql-connector-java-X.jar) — place inside `lib/` folder

## Setup steps
1. Import or extract the project.
2. Put MySQL JDBC driver into the `lib/` folder (example: `mysql-connector-java-8.0.33.jar`).
3. Edit DB credentials in `src/com/travel/app/Conn.java` (URL, USER, PASS).
4. Create the database and tables:
   - Run the SQL script located at `sql/schema.sql` using MySQL Workbench or command line:
     ```
     mysql -u root -p < sql/schema.sql
     ```
5. Build and run with Ant:
   - Compile: `ant compile`
   - Run (from project root): `ant run`
   - Create JAR: `ant jar` (output -> `dist/TravelProject.jar`)

## Notes
- This is a starter/demo implementation based on your PDF. It includes basic auth, add/view customers.
- Passwords are stored in plain text in this demo database for simplicity. For production, always store hashed passwords.
- Expand modules (package booking, hotels, payments) by following the pattern in `AddCustomerWindow` and `ViewCustomersWindow`.

## Files of interest
- `src/com/travel/app/Conn.java` -- DB connection helper
- `src/com/travel/app/LoginWindow.java` -- login screen
- `src/com/travel/app/Dashboard.java` -- main navigation
- `src/com/travel/app/AddCustomerWindow.java` -- add customer form
- `src/com/travel/app/ViewCustomersWindow.java` -- view/search customers
- `sql/schema.sql` -- database schema and sample admin account
- `build.xml` -- Ant build file

## Need help?
Reply here and I will:
- Change DB fields/names to match your exact PDF columns
- Add more screens (Package booking, Hotel reservation, Payment)
- Provide a ready-to-run zip with connector jar included (if you allow me to include driver)
