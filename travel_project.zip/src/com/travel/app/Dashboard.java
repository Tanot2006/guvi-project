package com.travel.app;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Dashboard extends JFrame {
    private String username, role;
    public Dashboard(String username, String role) {
        this.username = username;
        this.role = role;
        setTitle("Dashboard - " + username + " (" + role + ")");
        setSize(600,400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        init();
    }

    private void init() {
        JPanel top = new JPanel();
        top.add(new JLabel("Welcome, " + username));
        add(top, BorderLayout.NORTH);

        JPanel center = new JPanel(new GridLayout(2,2,10,10));
        JButton addCust = new JButton("Add Customer");
        addCust.addActionListener(e -> {
            AddCustomerWindow ac = new AddCustomerWindow();
            ac.setVisible(true);
        });
        center.add(addCust);

        JButton viewCust = new JButton("View Customers");
        viewCust.addActionListener(e -> {
            ViewCustomersWindow vc = new ViewCustomersWindow();
            vc.setVisible(true);
        });
        center.add(viewCust);

        JButton managePackages = new JButton("Manage Packages");
        managePackages.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Package management not implemented in this demo.");
        });
        center.add(managePackages);

        JButton exit = new JButton("Logout");
        exit.addActionListener(e -> {
            this.dispose();
            LoginWindow lw = new LoginWindow();
            lw.setVisible(true);
        });
        center.add(exit);

        add(center, BorderLayout.CENTER);
    }
}
