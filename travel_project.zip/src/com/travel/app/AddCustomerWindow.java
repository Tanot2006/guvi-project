package com.travel.app;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class AddCustomerWindow extends JFrame {
    private JTextField nameField, phoneField, emailField;
    private JButton saveBtn;

    public AddCustomerWindow() {
        setTitle("Add Customer");
        setSize(400,250);
        setLocationRelativeTo(null);
        init();
    }

    private void init() {
        JPanel p = new JPanel(new GridLayout(4,2,8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        p.add(new JLabel("Name:"));
        nameField = new JTextField();
        p.add(nameField);

        p.add(new JLabel("Phone:"));
        phoneField = new JTextField();
        p.add(phoneField);

        p.add(new JLabel("Email:"));
        emailField = new JTextField();
        p.add(emailField);

        saveBtn = new JButton("Save");
        saveBtn.addActionListener(e -> saveCustomer());
        p.add(new JLabel());
        p.add(saveBtn);
        add(p);
    }

    private void saveCustomer() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name required", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = Conn.getConnection()) {
            String sql = "INSERT INTO Customer (name, phone, email) VALUES (?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, name);
                ps.setString(2, phone);
                ps.setString(3, email);
                ps.executeUpdate();
                JOptionPane.showMessageDialog(this, "Customer saved.");
                this.dispose();
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "DB error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
