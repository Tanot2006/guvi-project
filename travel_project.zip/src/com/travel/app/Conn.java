package com.travel.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conn {
    // Update these constants with your MySQL credentials
    private static final String URL = "jdbc:mysql://localhost:3306/travel_db";
    private static final String USER = "root";
    private static final String PASS = "password";

    public static Connection getConnection() throws SQLException {
        // Ensure MySQL JDBC driver is available on classpath (put connector jar in lib/)
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found. Add connector jar to lib/ folder.");
        }
        return DriverManager.getConnection(URL, USER, PASS);
    }
}
