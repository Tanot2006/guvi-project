package com.travel.app;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginWindow lw = new LoginWindow();
            lw.setVisible(true);
        });
    }
}
