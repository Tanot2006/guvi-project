package com.travel.app;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class ViewCustomersWindow extends JFrame {
    private JTable table;
    public ViewCustomersWindow() {
        setTitle("Customers");
        setSize(600,400);
        setLocationRelativeTo(null);
        init();
    }

    private void init() {
        table = new JTable();
        loadData();
        add(new JScrollPane(table), BorderLayout.CENTER);
    }

    private void loadData() {
        try (Connection conn = Conn.getConnection()) {
            String sql = "SELECT id, name, phone, email FROM Customer";
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                ResultSetMetaData md = rs.getMetaData();
                int cols = md.getColumnCount();
                Vector<String> colNames = new Vector<>();
                for (int i=1;i<=cols;i++) colNames.add(md.getColumnName(i));
                Vector<Vector<Object>> data = new Vector<>();
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    for (int i=1;i<=cols;i++) row.add(rs.getObject(i));
                    data.add(row);
                }
                DefaultTableModel model = new DefaultTableModel(data, colNames) {
                    public boolean isCellEditable(int row, int column) { return false; }
                };
                table.setModel(model);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "DB error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
